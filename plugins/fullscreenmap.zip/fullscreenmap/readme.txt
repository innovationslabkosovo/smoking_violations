=== About ===
name: Full Screen Map
website: http://www.ushahidi.com
description: Render a full screen map with a modal window from main page
version: 0.6
requires: 2.0
tested up to: 2.0
author: David Kobia
author website: http://www.dkfactor.com

== Description ==

== Installation ==
1. Copy the entire /fullscreenmap/ directory into your /plugins/ directory.
2. Activate the plugin.

== Changelog ==
== 0.6
* Now compatible with jQuery +1.4