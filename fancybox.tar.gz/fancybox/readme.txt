iframe.html should be in main /var/www/smoking_violations/ in order to load the cluster files.
